package analyzer;

public enum ExperimentalSetup {
	CV,LOGOCV
}
